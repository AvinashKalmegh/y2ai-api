from fastapi import FastAPI
from .api_processed_articles import app as articles_app
from .dials_api import app as dials_app

app = FastAPI(title="Y2AI API")

app.mount("/articles", articles_app)
app.mount("/dials", dials_app)